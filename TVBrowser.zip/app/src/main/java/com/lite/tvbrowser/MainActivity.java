package com.lite.tvbrowser;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String HOME = "https://www.google.com";
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private FrameLayout root;
    private LinearLayout toolbar;
    private WebView web;
    private EditText urlBar;
    private ProgressBar progress;
    private CursorView cursor;
    private Button uaBtn;
    private FrameLayout customContainer;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private WebChromeClient chrome;

    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable hideCursor = new Runnable() {
        @Override public void run() { cursor.setVisibility(View.INVISIBLE); }
    };

    private float cx, cy;
    private boolean desktop = true;
    private boolean longDone = false;
    private boolean swallow = false;
    private long lastBack = 0;
    private String defaultUA;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences("tvb", MODE_PRIVATE);
        desktop = prefs.getBoolean("desktop", true);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        toolbar = buildToolbar();
        col.addView(toolbar, new LinearLayout.LayoutParams(MATCH, dp(52)));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.INVISIBLE);
        col.addView(progress, new LinearLayout.LayoutParams(MATCH, dp(3)));

        web = new WebView(this);
        col.addView(web, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        root.addView(col, new FrameLayout.LayoutParams(MATCH, MATCH));

        customContainer = new FrameLayout(this);
        customContainer.setBackgroundColor(Color.BLACK);
        customContainer.setVisibility(View.GONE);
        root.addView(customContainer, new FrameLayout.LayoutParams(MATCH, MATCH));

        cursor = new CursorView(this);
        root.addView(cursor, new FrameLayout.LayoutParams(MATCH, MATCH));

        setContentView(root);
        root.setFocusable(true);
        root.setFocusableInTouchMode(true);
        root.requestFocus();

        setupWebView();

        root.post(new Runnable() {
            @Override public void run() {
                cx = root.getWidth() / 2f;
                cy = root.getHeight() / 2f;
                cursor.setPos(cx, cy);
                showCursor();
            }
        });

        openFromIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        openFromIntent(intent);
    }

    private void openFromIntent(Intent i) {
        String d = i != null ? i.getDataString() : null;
        web.loadUrl(d != null ? d : HOME);
    }

    // ---------------------------------------------------------------- UI

    private LinearLayout buildToolbar() {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.HORIZONTAL);
        t.setBackgroundColor(0xFF202124);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(6), dp(4), dp(6), dp(4));

        t.addView(btn("Back", new View.OnClickListener() {
            @Override public void onClick(View v) { if (web.canGoBack()) web.goBack(); }
        }));
        t.addView(btn("Fwd", new View.OnClickListener() {
            @Override public void onClick(View v) { if (web.canGoForward()) web.goForward(); }
        }));
        t.addView(btn("Reload", new View.OnClickListener() {
            @Override public void onClick(View v) { web.reload(); }
        }));
        t.addView(btn("Home", new View.OnClickListener() {
            @Override public void onClick(View v) { web.loadUrl(HOME); }
        }));

        urlBar = new EditText(this);
        urlBar.setSingleLine(true);
        urlBar.setTextColor(Color.WHITE);
        urlBar.setHintTextColor(0xFF9AA0A6);
        urlBar.setHint("Search or type address");
        urlBar.setTextSize(15);
        urlBar.setBackgroundColor(0xFF303134);
        urlBar.setPadding(dp(10), 0, dp(10), 0);
        urlBar.setSelectAllOnFocus(true);
        urlBar.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlBar.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_GO);
        urlBar.setOnEditorActionListener(new android.widget.TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(android.widget.TextView v, int a, KeyEvent ev) {
                go();
                return true;
            }
        });
        urlBar.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.showSoftInput(urlBar, 0);
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, MATCH, 1f);
        lp.setMargins(dp(3), dp(1), dp(3), dp(1));
        t.addView(urlBar, lp);

        t.addView(btn("Go", new View.OnClickListener() {
            @Override public void onClick(View v) { go(); }
        }));
        t.addView(btn("Zoom-", new View.OnClickListener() {
            @Override public void onClick(View v) { web.zoomOut(); }
        }));
        t.addView(btn("Zoom+", new View.OnClickListener() {
            @Override public void onClick(View v) { web.zoomIn(); }
        }));
        uaBtn = btn(desktop ? "Desktop" : "Mobile", new View.OnClickListener() {
            @Override public void onClick(View v) {
                desktop = !desktop;
                prefs.edit().putBoolean("desktop", desktop).apply();
                uaBtn.setText(desktop ? "Desktop" : "Mobile");
                applyUA();
                web.reload();
            }
        });
        t.addView(uaBtn);
        t.addView(btn("Hide", new View.OnClickListener() {
            @Override public void onClick(View v) { toolbar.setVisibility(View.GONE); }
        }));
        return t;
    }

    private Button btn(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(0xFF3C4043);
        b.setFocusable(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(10), 0, dp(10), 0);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, MATCH);
        lp.setMargins(dp(3), dp(1), dp(3), dp(1));
        b.setLayoutParams(lp);
        return b;
    }

    private void setupWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        defaultUA = s.getUserAgentString();
        applyUA();

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                return !(u.startsWith("http") || u.startsWith("file:") || u.startsWith("about:") || u.startsWith("data:"));
            }
            @Override public void onPageStarted(WebView v, String url, Bitmap icon) {
                if (!urlBar.hasFocus()) urlBar.setText(url);
                progress.setProgress(0);
                progress.setVisibility(View.VISIBLE);
            }
            @Override public void onPageFinished(WebView v, String url) {
                progress.setVisibility(View.INVISIBLE);
            }
        });

        chrome = new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) { progress.setProgress(p); }

            @Override public void onShowCustomView(View view, CustomViewCallback cb) {
                if (customView != null) { cb.onCustomViewHidden(); return; }
                customView = view;
                customCb = cb;
                customContainer.addView(view, new FrameLayout.LayoutParams(MATCH, MATCH));
                customContainer.setVisibility(View.VISIBLE);
            }

            @Override public void onHideCustomView() {
                if (customView == null) return;
                customContainer.removeView(customView);
                customContainer.setVisibility(View.GONE);
                customView = null;
                if (customCb != null) customCb.onCustomViewHidden();
                customCb = null;
            }
        };
        web.setWebChromeClient(chrome);
    }

    private void applyUA() {
        WebSettings s = web.getSettings();
        if (desktop) {
            String ver = "120.0.0.0";
            Matcher m = Pattern.compile("Chrome/([\\d.]+)").matcher(defaultUA);
            if (m.find()) ver = m.group(1);
            s.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
                    + ver + " Safari/537.36");
        } else {
            s.setUserAgentString(defaultUA);
        }
    }

    // ------------------------------------------------------- navigation

    private String toUrl(String q) {
        if (q.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) return q;
        if (!q.contains(" ") && q.contains(".")) return "https://" + q;
        return "https://www.google.com/search?q=" + Uri.encode(q);
    }

    private void go() {
        String q = urlBar.getText().toString().trim();
        if (!q.isEmpty()) web.loadUrl(toUrl(q));
        leaveUrlBar();
    }

    private void leaveUrlBar() {
        urlBar.clearFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
        root.requestFocus();
    }

    private void handleBack() {
        if (customView != null) { chrome.onHideCustomView(); return; }
        if (web.canGoBack()) { web.goBack(); return; }
        long now = SystemClock.uptimeMillis();
        if (now - lastBack < 2000) {
            finish();
        } else {
            lastBack = now;
            Toast.makeText(this, "Press Back again to exit", Toast.LENGTH_SHORT).show();
        }
    }

    // ----------------------------------------------------------- cursor

    private void showCursor() {
        cursor.setVisibility(View.VISIBLE);
        handler.removeCallbacks(hideCursor);
        handler.postDelayed(hideCursor, 5000);
    }

    private void moveCursor(int key, int repeat) {
        float step = dpf(10 + Math.min(repeat, 30) * 1.5f);
        float dx = 0, dy = 0;
        if (key == KeyEvent.KEYCODE_DPAD_LEFT) dx = -step;
        else if (key == KeyEvent.KEYCODE_DPAD_RIGHT) dx = step;
        else if (key == KeyEvent.KEYCODE_DPAD_UP) dy = -step;
        else if (key == KeyEvent.KEYCODE_DPAD_DOWN) dy = step;

        int w = root.getWidth(), h = root.getHeight();

        // Edge scrolling (not while a fullscreen video is showing)
        if (customView == null) {
            float webTop = web.getTop();
            if (dy > 0 && cy >= h - dpf(30) && web.canScrollVertically(1)) {
                web.scrollBy(0, (int) (step * 2)); return;
            }
            if (dy < 0 && cy >= webTop && cy <= webTop + dpf(30) && web.canScrollVertically(-1)) {
                web.scrollBy(0, (int) (-step * 2)); return;
            }
            if (dx > 0 && cx >= w - dpf(20) && web.canScrollHorizontally(1)) {
                web.scrollBy((int) (step * 2), 0); return;
            }
            if (dx < 0 && cx <= dpf(20) && web.canScrollHorizontally(-1)) {
                web.scrollBy((int) (-step * 2), 0); return;
            }
        }

        cx = Math.max(0, Math.min(w - 1, cx + dx));
        cy = Math.max(0, Math.min(h - 1, cy + dy));
        cursor.setPos(cx, cy);
    }

    private void click() {
        final float x = cx, y = cy;
        final long t = SystemClock.uptimeMillis();
        MotionEvent d = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0);
        d.setSource(InputDevice.SOURCE_TOUCHSCREEN);
        root.dispatchTouchEvent(d);
        d.recycle();
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                MotionEvent u = MotionEvent.obtain(t, SystemClock.uptimeMillis(), MotionEvent.ACTION_UP, x, y, 0);
                u.setSource(InputDevice.SOURCE_TOUCHSCREEN);
                root.dispatchTouchEvent(u);
                u.recycle();
            }
        }, 40);
    }

    private void jumpToToolbar() {
        toolbar.setVisibility(View.VISIBLE);
        root.post(new Runnable() {
            @Override public void run() {
                cx = toolbar.getLeft() + urlBar.getLeft() + urlBar.getWidth() / 2f;
                cy = toolbar.getHeight() / 2f;
                cursor.setPos(cx, cy);
                showCursor();
            }
        });
    }

    private void toggleToolbar() {
        if (toolbar.getVisibility() == View.VISIBLE) toolbar.setVisibility(View.GONE);
        else jumpToToolbar();
    }

    // -------------------------------------------------------------- keys

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int k = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;

        if (urlBar.hasFocus()) {
            if (k == KeyEvent.KEYCODE_BACK) {
                if (!down) leaveUrlBar();
                return true;
            }
            return super.dispatchKeyEvent(e);
        }

        switch (k) {
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                showCursor();
                if (down) moveCursor(k, e.getRepeatCount());
                return true;

            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
            case KeyEvent.KEYCODE_BUTTON_A:
                if (down) {
                    if (e.getRepeatCount() == 0) {
                        swallow = cursor.getVisibility() != View.VISIBLE;
                        longDone = false;
                    } else if (!longDone && e.getEventTime() - e.getDownTime() > 700) {
                        longDone = true;
                        jumpToToolbar();
                    }
                } else {
                    if (!longDone && !swallow) click();
                    longDone = false;
                    swallow = false;
                }
                showCursor();
                return true;

            case KeyEvent.KEYCODE_BACK:
                if (!down) handleBack();
                return true;

            case KeyEvent.KEYCODE_MENU:
            case KeyEvent.KEYCODE_INFO:
            case KeyEvent.KEYCODE_PROG_RED:
                if (!down) toggleToolbar();
                return true;

            case KeyEvent.KEYCODE_CHANNEL_UP:
            case KeyEvent.KEYCODE_PAGE_UP:
            case KeyEvent.KEYCODE_MEDIA_REWIND:
                if (down) web.pageUp(false);
                return true;

            case KeyEvent.KEYCODE_CHANNEL_DOWN:
            case KeyEvent.KEYCODE_PAGE_DOWN:
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                if (down) web.pageDown(false);
                return true;

            default:
                return super.dispatchKeyEvent(e);
        }
    }

    // --------------------------------------------------------- lifecycle

    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        web.destroy();
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    // ----------------------------------------------------------- helpers

    private float dpf(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private int dp(float v) { return (int) dpf(v); }

    /** The on-screen mouse pointer. Draws only; never takes touches. */
    static class CursorView extends View {
        private float x, y;
        private final float scale;
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        CursorView(Context c) {
            super(c);
            scale = c.getResources().getDisplayMetrics().density * 1.4f;
            fill.setColor(Color.WHITE);
            fill.setStyle(Paint.Style.FILL);
            stroke.setColor(Color.BLACK);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(1.6f);
            path.moveTo(0, 0);
            path.lineTo(0, 22);
            path.lineTo(5, 17);
            path.lineTo(9, 26);
            path.lineTo(13, 24);
            path.lineTo(9, 16);
            path.lineTo(16, 16);
            path.close();
            setClickable(false);
            setFocusable(false);
        }

        void setPos(float nx, float ny) { x = nx; y = ny; invalidate(); }

        @Override protected void onDraw(Canvas canvas) {
            canvas.save();
            canvas.translate(x, y);
            canvas.scale(scale, scale);
            canvas.drawPath(path, fill);
            canvas.drawPath(path, stroke);
            canvas.restore();
        }
    }
}
