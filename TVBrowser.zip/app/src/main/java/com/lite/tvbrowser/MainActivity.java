package com.lite.tvbrowser;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.URLUtil;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.mozilla.geckoview.AllowOrDeny;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoRuntimeSettings;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSessionSettings;
import org.mozilla.geckoview.GeckoView;
import org.mozilla.geckoview.ScreenLength;
import org.mozilla.geckoview.WebExtension;
import org.mozilla.geckoview.WebExtensionController;
import org.mozilla.geckoview.WebResponse;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Proxy;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;

/**
 * Lightweight TV browser on GeckoView (Firefox engine) so real Firefox
 * extensions can be installed and run. Remote-controlled mouse cursor.
 */
public class MainActivity extends Activity {

    private static final String HOME = "resource://android/assets/home.html";
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int DLG = android.R.style.Theme_Material_Dialog_Alert;

    private static GeckoRuntime sRuntime;

    private FrameLayout root;
    private LinearLayout toolbar;
    private GeckoView gecko;
    private GeckoSession session;
    private EditText urlBar;
    private ProgressBar progress;
    private CursorView cursor;
    private Button uaBtn;

    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable hideCursor = new Runnable() {
        @Override public void run() { cursor.setVisibility(View.INVISIBLE); }
    };

    private String pUrl, pCd, pMime;
    private BroadcastReceiver dlDone;

    private float cx, cy;
    private boolean desktop = true;
    private boolean canBack = false;
    private boolean fullscreen = false;
    private boolean toolbarWasVisible = true;
    private int scrollY = 0;
    private float fontFactor = 1f;
    private boolean longDone = false;
    private boolean swallow = false;
    private long lastBack = 0;

    // ------------------------------------------------------------ create

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences("tvb", MODE_PRIVATE);
        desktop = prefs.getBoolean("desktop", true);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        toolbar = buildToolbar();
        col.addView(toolbar, new LinearLayout.LayoutParams(MATCH, dp(56)));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.getProgressDrawable().setColorFilter(0xFF8AB4F8, PorterDuff.Mode.SRC_IN);
        progress.setVisibility(View.INVISIBLE);
        col.addView(progress, new LinearLayout.LayoutParams(MATCH, dp(3)));

        gecko = new GeckoView(this);
        col.addView(gecko, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        root.addView(col, new FrameLayout.LayoutParams(MATCH, MATCH));

        cursor = new CursorView(this);
        root.addView(cursor, new FrameLayout.LayoutParams(MATCH, MATCH));

        setContentView(root);
        root.setFocusable(true);
        root.setFocusableInTouchMode(true);
        root.requestFocus();

        setupGecko();
        registerDownloadReceiver();

        root.post(new Runnable() {
            @Override public void run() {
                cx = root.getWidth() / 2f;
                cy = root.getHeight() / 2f;
                cursor.setPos(cx, cy);
                showCursor();
            }
        });

        openFromIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        openFromIntent(intent);
    }

    private void openFromIntent(Intent i) {
        String d = i != null ? i.getDataString() : null;
        session.loadUri(d != null ? d : HOME);
    }

    // ----------------------------------------------------------- gecko

    private void setupGecko() {
        if (sRuntime == null) {
            GeckoRuntimeSettings rs = new GeckoRuntimeSettings.Builder()
                    .extensionsWebAPIEnabled(true)   // lets addons.mozilla.org "Add to Firefox" work
                    .build();
            sRuntime = GeckoRuntime.create(getApplicationContext(), rs);
            installExtensionPromptDelegate();
        }
        fontFactor = prefs.getFloat("font", 1f);
        applyFont();

        GeckoSessionSettings ss = new GeckoSessionSettings.Builder()
                .userAgentMode(desktop ? GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
                        : GeckoSessionSettings.USER_AGENT_MODE_MOBILE)
                .viewportMode(desktop ? GeckoSessionSettings.VIEWPORT_MODE_DESKTOP
                        : GeckoSessionSettings.VIEWPORT_MODE_MOBILE)
                .build();
        session = new GeckoSession(ss);

        // NOTE: @Override is intentionally omitted on delegate methods so a small
        // signature change between GeckoView versions cannot break compilation.
        session.setNavigationDelegate(new GeckoSession.NavigationDelegate() {
            public void onCanGoBack(GeckoSession s, boolean can) { canBack = can; }
            public void onLocationChange(GeckoSession s, String url,
                    List<GeckoSession.PermissionDelegate.ContentPermission> perms) { locChanged(url); }
            public void onLocationChange(GeckoSession s, String url,
                    List<GeckoSession.PermissionDelegate.ContentPermission> perms, Boolean gesture) { locChanged(url); }
            public void onLocationChange(GeckoSession s, String url,
                    List<GeckoSession.PermissionDelegate.ContentPermission> perms, boolean gesture) { locChanged(url); }

            public GeckoResult<AllowOrDeny> onLoadRequest(GeckoSession s,
                    GeckoSession.NavigationDelegate.LoadRequest r) {
                String uri = r.uri;
                // Install links from the home page: https://tvb.install/?u=<xpi url>
                Uri u = Uri.parse(uri);
                if ("tvb.install".equals(u.getHost())) {
                    String x = u.getQueryParameter("u");
                    if (x != null) installExtension(x);
                    return GeckoResult.fromValue(AllowOrDeny.DENY);
                }
                String p = u.getPath();
                if (p != null && p.toLowerCase().endsWith(".xpi")) {
                    installExtension(uri);
                    return GeckoResult.fromValue(AllowOrDeny.DENY);
                }
                if (r.target == GeckoSession.NavigationDelegate.TARGET_WINDOW_NEW) {
                    session.loadUri(uri);
                    return GeckoResult.fromValue(AllowOrDeny.DENY);
                }
                return GeckoResult.fromValue(AllowOrDeny.ALLOW);
            }

            public GeckoResult<GeckoSession> onNewSession(GeckoSession s, String uri) {
                session.loadUri(uri);
                return null;
            }
        });

        session.setProgressDelegate(new GeckoSession.ProgressDelegate() {
            public void onPageStart(GeckoSession s, String url) {
                progress.setProgress(0);
                progress.setVisibility(View.VISIBLE);
            }
            public void onPageStop(GeckoSession s, boolean ok) { progress.setVisibility(View.INVISIBLE); }
            public void onProgressChange(GeckoSession s, int p) { progress.setProgress(p); }
        });

        session.setScrollDelegate(new GeckoSession.ScrollDelegate() {
            public void onScrollChanged(GeckoSession s, int x, int y) { scrollY = y; }
        });

        session.setContentDelegate(new GeckoSession.ContentDelegate() {
            public void onFullScreen(GeckoSession s, boolean full) {
                fullscreen = full;
                if (full) {
                    toolbarWasVisible = toolbar.getVisibility() == View.VISIBLE;
                    toolbar.setVisibility(View.GONE);
                } else if (toolbarWasVisible) {
                    toolbar.setVisibility(View.VISIBLE);
                }
            }
            public void onExternalResponse(GeckoSession s, WebResponse r) {
                String cd = null, mime = null;
                if (r.headers != null) {
                    for (Map.Entry<String, String> e : r.headers.entrySet()) {
                        if ("content-disposition".equalsIgnoreCase(e.getKey())) cd = e.getValue();
                        if ("content-type".equalsIgnoreCase(e.getKey())) mime = e.getValue();
                    }
                }
                startDownload(r.uri, cd, mime);
            }
        });

        session.setPromptDelegate(new GeckoSession.PromptDelegate() {
            public GeckoResult<PromptResponse> onAlertPrompt(GeckoSession s, final AlertPrompt p) {
                final GeckoResult<PromptResponse> res = new GeckoResult<>();
                new AlertDialog.Builder(MainActivity.this, DLG)
                        .setMessage(p.message)
                        .setPositiveButton("OK", null)
                        .setOnDismissListener(d -> res.complete(p.dismiss()))
                        .show();
                return res;
            }
            public GeckoResult<PromptResponse> onButtonPrompt(GeckoSession s, final ButtonPrompt p) {
                final GeckoResult<PromptResponse> res = new GeckoResult<>();
                new AlertDialog.Builder(MainActivity.this, DLG)
                        .setMessage(p.message)
                        .setPositiveButton("OK", (d, w) -> res.complete(p.confirm(ButtonPrompt.Type.POSITIVE)))
                        .setNegativeButton("Cancel", (d, w) -> res.complete(p.confirm(ButtonPrompt.Type.NEGATIVE)))
                        .setOnCancelListener(d -> res.complete(p.dismiss()))
                        .show();
                return res;
            }
            public GeckoResult<PromptResponse> onChoicePrompt(GeckoSession s, final ChoicePrompt p) {
                final GeckoResult<PromptResponse> res = new GeckoResult<>();
                final ChoicePrompt.Choice[] ch = p.choices;
                String[] labels = new String[ch.length];
                for (int i = 0; i < ch.length; i++) {
                    labels[i] = (ch[i].selected ? "* " : "") + ch[i].label;
                }
                new AlertDialog.Builder(MainActivity.this, DLG)
                        .setItems(labels, (d, w) -> res.complete(p.confirm(ch[w].id)))
                        .setOnCancelListener(d -> res.complete(p.dismiss()))
                        .show();
                return res;
            }
        });

        session.open(sRuntime);
        gecko.setSession(session);
    }

    private void locChanged(String url) {
        if (url == null) return;
        if (!urlBar.hasFocus()) {
            urlBar.setText(url.startsWith("resource://android/assets") || url.equals("about:blank") ? "" : url);
        }
    }

    private void applyFont() {
        try {
            sRuntime.getSettings().setAutomaticFontSizeAdjustment(false);
            sRuntime.getSettings().setFontSizeFactor(fontFactor);
        } catch (Throwable ignored) { }
    }

    private void changeFont(float delta) {
        fontFactor = Math.max(0.5f, Math.min(3f, fontFactor + delta));
        prefs.edit().putFloat("font", fontFactor).apply();
        applyFont();
        Toast.makeText(this, "Text size " + Math.round(fontFactor * 100) + "%", Toast.LENGTH_SHORT).show();
    }

    // -------------------------------------------------------- extensions

    /**
     * Asks the person before an extension installs. Built with a dynamic proxy so it
     * keeps working if GeckoView changes the exact PromptDelegate method signatures.
     */
    private void installExtensionPromptDelegate() {
        InvocationHandler h = new InvocationHandler() {
            @Override public Object invoke(Object proxy, java.lang.reflect.Method m, Object[] args) {
                String n = m.getName();
                if (m.getDeclaringClass() == Object.class) {
                    if (n.equals("equals")) return proxy == args[0];
                    if (n.equals("hashCode")) return System.identityHashCode(proxy);
                    return "TvbPromptDelegate";
                }
                if (m.getReturnType() != GeckoResult.class) return null;

                final java.lang.reflect.Method method = m;
                final GeckoResult<Object> res = new GeckoResult<>();
                if (!n.startsWith("onInstallPrompt")) {          // updates / optional permissions: allow
                    res.complete(answer(method, true));
                    return res;
                }
                String name = "this extension";
                StringBuilder perms = new StringBuilder();
                if (args != null) {
                    for (Object a : args) {
                        if (a instanceof WebExtension) {
                            WebExtension we = (WebExtension) a;
                            if (we.metaData != null && we.metaData.name != null) name = we.metaData.name;
                        } else if (a instanceof String[]) {
                            for (String s : (String[]) a) perms.append("\n- ").append(s);
                        }
                    }
                }
                final String msg = "Install " + name + "?"
                        + (perms.length() > 0 ? "\n\nIt can access:" + perms : "");
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        new AlertDialog.Builder(MainActivity.this, DLG)
                                .setMessage(msg)
                                .setPositiveButton("Install", (d, w) -> res.complete(answer(method, true)))
                                .setNegativeButton("Cancel", (d, w) -> res.complete(answer(method, false)))
                                .setOnCancelListener(d -> res.complete(answer(method, false)))
                                .show();
                    }
                });
                return res;
            }
        };
        Object proxy = Proxy.newProxyInstance(
                WebExtensionController.PromptDelegate.class.getClassLoader(),
                new Class<?>[]{WebExtensionController.PromptDelegate.class}, h);
        sRuntime.getWebExtensionController().setPromptDelegate((WebExtensionController.PromptDelegate) proxy);
    }

    /** Builds the right "allow/deny" value for whatever GeckoResult<T> the method returns. */
    private static Object answer(java.lang.reflect.Method m, boolean allow) {
        try {
            Type g = m.getGenericReturnType();
            Class<?> c = Object.class;
            if (g instanceof ParameterizedType) {
                Type a = ((ParameterizedType) g).getActualTypeArguments()[0];
                if (a instanceof Class) c = (Class<?>) a;
            }
            if (c != AllowOrDeny.class && c != Object.class) {
                for (Constructor<?> k : c.getDeclaredConstructors()) {
                    Class<?>[] p = k.getParameterTypes();
                    boolean allBool = p.length > 0;
                    for (Class<?> x : p) if (x != boolean.class) allBool = false;
                    if (allBool) {
                        Object[] v = new Object[p.length];
                        for (int i = 0; i < v.length; i++) v[i] = (i == 0) && allow;
                        k.setAccessible(true);
                        return k.newInstance(v);
                    }
                }
            }
        } catch (Throwable ignored) { }
        return allow ? AllowOrDeny.ALLOW : AllowOrDeny.DENY;
    }

    private void installExtension(String uri) {
        Toast.makeText(this, "Installing extension...", Toast.LENGTH_SHORT).show();
        sRuntime.getWebExtensionController().install(uri).accept(
                ext -> runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Installed: " + (ext != null && ext.metaData != null ? ext.metaData.name : "extension"),
                        Toast.LENGTH_LONG).show()),
                err -> runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Install failed or cancelled", Toast.LENGTH_LONG).show()));
    }

    private void showInstalledExtensions() {
        sRuntime.getWebExtensionController().list().accept(
                list -> runOnUiThread(() -> showExtList(list)),
                err -> runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Could not list extensions", Toast.LENGTH_SHORT).show()));
    }

    private void showExtList(final List<WebExtension> list) {
        if (list == null || list.isEmpty()) {
            Toast.makeText(this, "No extensions installed", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] names = new String[list.size()];
        for (int i = 0; i < names.length; i++) {
            WebExtension e = list.get(i);
            names[i] = e.metaData != null && e.metaData.name != null ? e.metaData.name : e.id;
        }
        new AlertDialog.Builder(this, DLG)
                .setTitle("Installed extensions (select to remove)")
                .setItems(names, (d, w) -> {
                    final WebExtension ext = list.get(w);
                    sRuntime.getWebExtensionController().uninstall(ext).accept(
                            v -> runOnUiThread(() -> Toast.makeText(MainActivity.this, "Removed", Toast.LENGTH_SHORT).show()),
                            err -> runOnUiThread(() -> Toast.makeText(MainActivity.this, "Could not remove", Toast.LENGTH_SHORT).show()));
                })
                .setNegativeButton("Close", null)
                .show();
    }

    // ----------------------------------------------------------- toolbar

    private LinearLayout buildToolbar() {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.HORIZONTAL);
        t.setBackgroundColor(0xFF161618);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(8), dp(5), dp(8), dp(5));

        t.addView(btn("Back", false, new View.OnClickListener() {
            @Override public void onClick(View v) { if (canBack) session.goBack(); }
        }));
        t.addView(btn("Fwd", false, new View.OnClickListener() {
            @Override public void onClick(View v) { session.goForward(); }
        }));
        t.addView(btn("Reload", false, new View.OnClickListener() {
            @Override public void onClick(View v) { session.reload(); }
        }));
        t.addView(btn("Home", false, new View.OnClickListener() {
            @Override public void onClick(View v) { session.loadUri(HOME); }
        }));

        urlBar = new EditText(this);
        urlBar.setSingleLine(true);
        urlBar.setTextColor(Color.WHITE);
        urlBar.setHintTextColor(0xFF8E9399);
        urlBar.setHint("Search or type address");
        urlBar.setTextSize(15);
        urlBar.setBackground(pill(0xFF2A2B2E, 20));
        urlBar.setPadding(dp(16), 0, dp(16), 0);
        urlBar.setSelectAllOnFocus(true);
        urlBar.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlBar.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_GO);
        urlBar.setOnEditorActionListener(new android.widget.TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(android.widget.TextView v, int a, KeyEvent ev) {
                go();
                return true;
            }
        });
        urlBar.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.showSoftInput(urlBar, 0);
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, MATCH, 1f);
        lp.setMargins(dp(4), dp(1), dp(4), dp(1));
        t.addView(urlBar, lp);

        t.addView(btn("Go", true, new View.OnClickListener() {
            @Override public void onClick(View v) { go(); }
        }));
        t.addView(btn("A-", false, new View.OnClickListener() {
            @Override public void onClick(View v) { changeFont(-0.1f); }
        }));
        t.addView(btn("A+", false, new View.OnClickListener() {
            @Override public void onClick(View v) { changeFont(0.1f); }
        }));
        uaBtn = btn(desktop ? "Desktop" : "Mobile", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                desktop = !desktop;
                prefs.edit().putBoolean("desktop", desktop).apply();
                uaBtn.setText(desktop ? "Desktop" : "Mobile");
                session.getSettings().setUserAgentMode(desktop ? GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
                        : GeckoSessionSettings.USER_AGENT_MODE_MOBILE);
                session.getSettings().setViewportMode(desktop ? GeckoSessionSettings.VIEWPORT_MODE_DESKTOP
                        : GeckoSessionSettings.VIEWPORT_MODE_MOBILE);
                session.reload();
            }
        }));
        t.addView(uaBtn);
        t.addView(btn("Ext", false, new View.OnClickListener() {
            @Override public void onClick(View v) { showInstalledExtensions(); }
        }));
        t.addView(btn("Files", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Saved in the Downloads folder", Toast.LENGTH_LONG).show();
                }
            }
        }));
        t.addView(btn("Hide", false, new View.OnClickListener() {
            @Override public void onClick(View v) { toolbar.setVisibility(View.GONE); }
        }));
        return t;
    }

    private GradientDrawable pill(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dpf(radiusDp));
        return g;
    }

    private Button btn(String text, boolean accent, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(Color.WHITE);
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_pressed}, pill(accent ? 0xFF1557B0 : 0xFF5F6368, 20));
        sl.addState(new int[]{}, pill(accent ? 0xFF1A73E8 : 0xFF2F3033, 20));
        b.setBackground(sl);
        b.setStateListAnimator(null);
        b.setFocusable(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(12), 0, dp(12), 0);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, MATCH);
        lp.setMargins(dp(2), dp(1), dp(2), dp(1));
        b.setLayoutParams(lp);
        return b;
    }

    // --------------------------------------------------------- downloads

    private void registerDownloadReceiver() {
        dlDone = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                Toast.makeText(MainActivity.this, "Download finished - saved in Downloads", Toast.LENGTH_LONG).show();
            }
        };
        IntentFilter f = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(dlDone, f, Context.RECEIVER_EXPORTED);
        else registerReceiver(dlDone, f);
    }

    private void startDownload(String url, String cd, String mime) {
        if (url == null) return;
        if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT <= 28
                && checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            pUrl = url; pCd = cd; pMime = mime;
            requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 7);
            return;
        }
        try {
            String name = URLUtil.guessFileName(url, cd, mime);
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            r.setTitle(name);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
            Toast.makeText(this, "Downloading " + name, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Download failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == 7 && res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED && pUrl != null) {
            startDownload(pUrl, pCd, pMime);
        } else if (code == 7) {
            Toast.makeText(this, "Storage permission is needed to save files", Toast.LENGTH_LONG).show();
        }
        pUrl = null;
    }

    // -------------------------------------------------------- navigation

    private String toUrl(String q) {
        if (q.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) return q;
        if (!q.contains(" ") && q.contains(".")) return "https://" + q;
        return "https://www.google.com/search?q=" + Uri.encode(q);
    }

    private void go() {
        String q = urlBar.getText().toString().trim();
        if (!q.isEmpty()) session.loadUri(toUrl(q));
        leaveUrlBar();
    }

    private void leaveUrlBar() {
        urlBar.clearFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
        root.requestFocus();
    }

    private void handleBack() {
        if (fullscreen) { session.exitFullScreen(); return; }
        if (canBack) { session.goBack(); return; }
        long now = SystemClock.uptimeMillis();
        if (now - lastBack < 2000) {
            finish();
        } else {
            lastBack = now;
            Toast.makeText(this, "Press Back again to exit", Toast.LENGTH_SHORT).show();
        }
    }

    private void scrollPx(float dx, float dy) {
        session.getPanZoomController().scrollBy(
                ScreenLength.fromPixels(dx), ScreenLength.fromPixels(dy));
    }

    // ------------------------------------------------------------ cursor

    private void showCursor() {
        cursor.setVisibility(View.VISIBLE);
        handler.removeCallbacks(hideCursor);
        handler.postDelayed(hideCursor, 5000);
    }

    private void moveCursor(int key, int repeat) {
        float step = dpf(10 + Math.min(repeat, 30) * 1.5f);
        float dx = 0, dy = 0;
        if (key == KeyEvent.KEYCODE_DPAD_LEFT) dx = -step;
        else if (key == KeyEvent.KEYCODE_DPAD_RIGHT) dx = step;
        else if (key == KeyEvent.KEYCODE_DPAD_UP) dy = -step;
        else if (key == KeyEvent.KEYCODE_DPAD_DOWN) dy = step;

        int w = root.getWidth(), h = root.getHeight();

        // Edge scrolling
        float webTop = ((View) gecko.getParent()).getTop() + gecko.getTop();
        if (dy > 0 && cy >= h - dpf(30)) { scrollPx(0, step * 2); return; }
        if (dy < 0 && cy >= webTop && cy <= webTop + dpf(30) && scrollY > 0) { scrollPx(0, -step * 2); return; }
        if (dx > 0 && cx >= w - dpf(20)) { scrollPx(step * 2, 0); return; }
        if (dx < 0 && cx <= dpf(20)) { scrollPx(-step * 2, 0); return; }

        cx = Math.max(0, Math.min(w - 1, cx + dx));
        cy = Math.max(0, Math.min(h - 1, cy + dy));
        cursor.setPos(cx, cy);
    }

    private void click() {
        final float x = cx, y = cy;
        final long t = SystemClock.uptimeMillis();
        MotionEvent d = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0);
        d.setSource(InputDevice.SOURCE_TOUCHSCREEN);
        root.dispatchTouchEvent(d);
        d.recycle();
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                MotionEvent u = MotionEvent.obtain(t, SystemClock.uptimeMillis(), MotionEvent.ACTION_UP, x, y, 0);
                u.setSource(InputDevice.SOURCE_TOUCHSCREEN);
                root.dispatchTouchEvent(u);
                u.recycle();
            }
        }, 60);
    }

    private void jumpToToolbar() {
        toolbar.setVisibility(View.VISIBLE);
        root.post(new Runnable() {
            @Override public void run() {
                cx = toolbar.getLeft() + urlBar.getLeft() + urlBar.getWidth() / 2f;
                cy = toolbar.getHeight() / 2f;
                cursor.setPos(cx, cy);
                showCursor();
            }
        });
    }

    private void toggleToolbar() {
        if (toolbar.getVisibility() == View.VISIBLE) toolbar.setVisibility(View.GONE);
        else jumpToToolbar();
    }

    // -------------------------------------------------------------- keys

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int k = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;

        if (urlBar.hasFocus()) {
            if (k == KeyEvent.KEYCODE_BACK) {
                if (!down) leaveUrlBar();
                return true;
            }
            return super.dispatchKeyEvent(e);
        }

        switch (k) {
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                showCursor();
                if (down) moveCursor(k, e.getRepeatCount());
                return true;

            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
            case KeyEvent.KEYCODE_BUTTON_A:
                if (down) {
                    if (e.getRepeatCount() == 0) {
                        swallow = cursor.getVisibility() != View.VISIBLE;
                        longDone = false;
                    } else if (!longDone && e.getEventTime() - e.getDownTime() > 700) {
                        longDone = true;
                        jumpToToolbar();
                    }
                } else {
                    if (!longDone && !swallow) click();
                    longDone = false;
                    swallow = false;
                }
                showCursor();
                return true;

            case KeyEvent.KEYCODE_BACK:
                if (!down) handleBack();
                return true;

            case KeyEvent.KEYCODE_MENU:
            case KeyEvent.KEYCODE_INFO:
            case KeyEvent.KEYCODE_PROG_RED:
                if (!down) toggleToolbar();
                return true;

            case KeyEvent.KEYCODE_CHANNEL_UP:
            case KeyEvent.KEYCODE_PAGE_UP:
            case KeyEvent.KEYCODE_MEDIA_REWIND:
                if (down) scrollPx(0, -gecko.getHeight() * 0.85f);
                return true;

            case KeyEvent.KEYCODE_CHANNEL_DOWN:
            case KeyEvent.KEYCODE_PAGE_DOWN:
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                if (down) scrollPx(0, gecko.getHeight() * 0.85f);
                return true;

            default:
                return super.dispatchKeyEvent(e);
        }
    }

    // --------------------------------------------------------- lifecycle

    @Override protected void onPause() { super.onPause(); session.setActive(false); }
    @Override protected void onResume() { super.onResume(); session.setActive(true); }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        try { unregisterReceiver(dlDone); } catch (Exception ignored) { }
        gecko.releaseSession();
        session.close();
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    // ----------------------------------------------------------- helpers

    private float dpf(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private int dp(float v) { return (int) dpf(v); }

    /** The on-screen mouse pointer. Draws only; never takes touches. */
    static class CursorView extends View {
        private float x, y;
        private final float scale;
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        CursorView(Context c) {
            super(c);
            scale = c.getResources().getDisplayMetrics().density * 1.4f;
            fill.setColor(Color.WHITE);
            fill.setStyle(Paint.Style.FILL);
            fill.setShadowLayer(4f, 1f, 2f, 0x88000000);
            setLayerType(LAYER_TYPE_SOFTWARE, null);
            stroke.setColor(Color.BLACK);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(1.6f);
            path.moveTo(0, 0);
            path.lineTo(0, 22);
            path.lineTo(5, 17);
            path.lineTo(9, 26);
            path.lineTo(13, 24);
            path.lineTo(9, 16);
            path.lineTo(16, 16);
            path.close();
            setClickable(false);
            setFocusable(false);
        }

        void setPos(float nx, float ny) { x = nx; y = ny; invalidate(); }

        @Override protected void onDraw(Canvas canvas) {
            canvas.save();
            canvas.translate(x, y);
            canvas.scale(scale, scale);
            canvas.drawPath(path, fill);
            canvas.drawPath(path, stroke);
            canvas.restore();
        }
    }
}
