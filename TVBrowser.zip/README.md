# TV Browser (TCL / Android TV / Google TV)

TV browser on GeckoView (the Firefox engine) with a remote-controlled mouse cursor. Installs real Firefox extensions.

## Remote controls
- D-pad: move cursor (hold to speed up). Push the cursor to the screen edge to scroll.
- OK / Enter: click at the cursor.
- Hold OK (about 1 second): jump cursor to the address bar (shows toolbar if hidden).
- Back: browser back / close fullscreen video / press twice to exit.
- Menu / Info / Red: show or hide toolbar.
- CH+/CH-, Page Up/Down, Rewind/Fast-forward: scroll a page.

## Build
Push to GitHub. Actions builds the APK: Actions tab > latest run > Artifacts > TV-Browser-APK.


## Extensions
Home page lists extensions from Firebase (Install button). Typing/opening any .xpi link also installs it. Ext button lists/removes installed ones. addons.mozilla.org also works.
